package ejb;

import data.User;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Stateless(name = "UserEJB")
@LocalBean
public class UserEJB {
    @PersistenceContext(name="MyBay")
    EntityManager em;




    public UserEJB() {
    }
    // Devolve 1 se foi bem sucedido, -1 se não
    public int login(String username, String password){
        System.out.println("In the EJB. Height = " + username);
        @SuppressWarnings("JpaQlInspection") Query q = em.createQuery("from User u where u.username=:t and u.password=md5(:x)");
        q.setParameter("t", username);
        q.setParameter("x",password);
        try {
            User result = (User) q.getSingleResult();
        }
        catch(NoResultException e){
            return -1;
        }
        return 1;
    }
    // Registar um utilizador
    // Devolve 1 se foi bem sucedido, -1 se não §
    public int register(String username,String country, String email, String password){
        User u = new User(username,country,email,password);
        try {
            em.persist(u);
        }
        catch(Exception e){
            return -1;
        }
        return 1;
    }
    public void populate(){
        User u = new User("Utilizador2","Portugal","utilizador1@gmail.com","password1");
        em.persist(u);
    }
}
