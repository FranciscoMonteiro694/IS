package data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name="Items")
public class Item implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "itemid", nullable = false)
    private int item_id;
    @Column(name = "name", nullable = false)
    private String name;
    @Column(name = "category", nullable = false)
    private String category;
    @Column(name = "countryOfOrigin", nullable = false)
    private String countryOfOrigin;
    @Column(name = "photograph", nullable = false)
    private String photograph; // Mete-se string?
    @Column(name = "price", nullable = false)
    private float price; // Em principio é preciso
    @Column(name = "dateOfInsertion", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date dateOfInsertion;

    // Relação com o user
    @ManyToOne
    @JoinColumn(name = "userid")
    private User user;




    public Item(){
    }

    public int getItem_id() {
        return item_id;
    }

    public void setItem_id(int item_id) {
        this.item_id = item_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCountryOfOrigin() {
        return countryOfOrigin;
    }

    public void setCountryOfOrigin(String countryOfOrigin) {
        this.countryOfOrigin = countryOfOrigin;
    }

    public String getPhotograph() {
        return photograph;
    }

    public void setPhotograph(String photograph) {
        this.photograph = photograph;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public Date getDateOfInsertion() {
        return dateOfInsertion;
    }

    public void setDateOfInsertion(Date dateOfInsertion) {
        this.dateOfInsertion = dateOfInsertion;
    }
}
