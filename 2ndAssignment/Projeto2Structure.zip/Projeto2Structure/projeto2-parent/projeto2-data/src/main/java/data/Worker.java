package data;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Worker {

    public static void main(String[] args) throws ParseException {
        //SimpleDateFormat ft = new SimpleDateFormat ("yyyy-MM-dd");


        User p = new User("Utilizador1","Portugal","utilizador1@gmail.com","password1");
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyBay");
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = em.getTransaction();

        transaction.begin();
        em.persist(p);
        transaction.commit();

}
}
